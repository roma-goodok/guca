# Quadmesh Organism Atlas — esd9-isl1-post-pl3-v1

Open `index.html` directly in a desktop browser. All assets are local; no server or network is needed. Detail records load on selection. The bundle contains selected organisms, never populations.

## Rebuild

Run in the GUCA repository with the audited source logbook present:

```sh
python -m guca.cli.export_organism_atlas --manifest docs/research/evolutionary-search-diagnostics/tickets/ESD-9/manifests/isl1-post-pl3-v1-canonical-score.yaml --output-dir artifacts/esd9/atlas-rebuild --cache-dir artifacts/visualization_caches/esd9 --workers 1
```

Build-only dependencies: the project Python environment and Node.js with d3-force v3 (the existing sibling GUCA package, or ATLAS_D3_FORCE_MODULE pointing to its src/index.js). Set --node-binary if Node is outside PATH. Add --validate-only with an existing output directory for a read-only checksum, source and aggregation audit.

## Scientific scope

Atlas fitness uses atlas-quadmesh-canonical-v1: exact canonical labeling of the complete topology, then the frozen bonus-free QuadMesh scorer. It is independent of source labels, states and insertion order. This is a deterministic embedding convention, not a best-embedding search and not the fitness recorded during evolution. Original replay scores and recorded experimental fitness are retained per source, including all differences. Topologies export the full-corpus original score range; fitness is an explicit compatibility alias of atlas_fitness. Canonical certificates and metrics are in data/topology-scores.json; original conflicts are in data/original-score-conflicts.json. A canonical certificate or score mismatch within an exact topology blocks publication. No scores are averaged.

Exact isomorphism ignores states and vertex IDs and retains all components.

Transition events represent observed champion changes within one run/island. The denominator contains all observed non-self departures from the source. Unobserved gaps break histories. Archive order is never a trajectory. Visits include the first observed episode and restart after a different form or a gap. Source variants explain champion ties and artifact aliases.

data/ contains versioned source evidence, full resolved configurations, histories, transitions and exact organism records. Topology IDs and labels are version-scoped, not universal canonical graph identifiers. Filtering changes cohort statistics, never the frozen coordinates. Display-only hiding never bridges nodes or renormalizes probabilities.

## Sampling and cohort units

All available uses the declared 500-generation grid; missing expected cuts break a history. Common 8 cuts uses 500/1000/2000/3000/5000/7500/10000/15000; links connect adjacent cuts of that explicit grid, and intermediate changes may be unobserved. Both modes respect the generation window and recompute frequencies and departure denominators. data/sampling/ exports the full-cohort summaries when both grids are declared.

The 24/48 presets select whole declared units within each hypothesis. A q6.35 portfolio contains four independent physical runs; a winning-member change never creates a transition. Point size counts physical runs. Numeric seed overlap across hypotheses does not create a shared observation. Island decoding uses each verified native continuation fingerprint, including encoding; root seeds identify physical runs and internal seeds identify island contexts.

This design study is descriptive. It makes no treatment ranking or inferential claim. Existing versions remain immutable. Visual contract: GUCA HTML Visual Guide v1.0, with the organism-state-edges-v1 shared default.
